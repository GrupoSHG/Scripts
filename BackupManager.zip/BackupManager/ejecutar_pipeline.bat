@echo off
:: ejecutar_pipeline.bat
:: Task Scheduler ejecuta este archivo cada día
set SCRIPT_DIR=C:\Scripts\BackupManager
set HORA=08:00
cd /d "%SCRIPT_DIR%"

echo %date% %time% - Iniciando pipeline >> "%SCRIPT_DIR%\pipeline_ventas.log"
python 00_pipeline_completo.py >> "%SCRIPT_DIR%\pipeline_ventas.log" 2>&1

if errorlevel 1 (
    echo %date% %time% - ERROR en el pipeline >> "%SCRIPT_DIR%\pipeline_ventas.log"
) else (
    echo %date% %time% - Pipeline completado OK >> "%SCRIPT_DIR%\pipeline_ventas.log"
)
