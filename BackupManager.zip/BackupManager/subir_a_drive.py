"""
02_subir_a_drive.py
====================
Sube el Excel generado a Google Drive usando cuenta de servicio.
Sin tokens, sin navegador, nunca expira.
 
Requiere: pip install google-auth google-api-python-client
"""
 
import logging
from pathlib import Path
 
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
 
# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
DRIVE_FOLDER_ID  = "1AOfDtBJRpZm6E6QwqCvLgeCnGCq_vnrA"
NOMBRE_EN_DRIVE  = "VentasFull_Actualizado.xlsx"
CREDENTIALS_FILE = r"C:\Users\atorr\Polchile\Credencialesbot.json"
# ─────────────────────────────────────────────
 
SCOPES = ["https://www.googleapis.com/auth/drive"]
 
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler("pipeline_ventas.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)
 
 
def autenticar():
    creds = service_account.Credentials.from_service_account_file(
        CREDENTIALS_FILE,
        scopes=SCOPES
    )
    return build("drive", "v3", credentials=creds)
 
 
def buscar_archivo_existente(service, nombre: str) -> str | None:
    query = (
        f"name='{nombre}' and "
        f"'{DRIVE_FOLDER_ID}' in parents and "
        f"trashed=false"
    )
    resultado = service.files().list(q=query, fields="files(id, name)").execute()
    archivos  = resultado.get("files", [])
    return archivos[0]["id"] if archivos else None
 
 
def subir_excel(ruta_excel: Path) -> str:
    log.info("Autenticando con cuenta de servicio...")
    service = autenticar()
 
    mime  = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    media = MediaFileUpload(str(ruta_excel), mimetype=mime, resumable=True)
 
    archivo_id = buscar_archivo_existente(service, NOMBRE_EN_DRIVE)
 
    if archivo_id:
        log.info(f"Actualizando archivo existente (ID: {archivo_id})...")
        service.files().update(
            fileId=archivo_id,
            media_body=media
        ).execute()
        log.info(f"✅ Archivo actualizado: {NOMBRE_EN_DRIVE}")
    else:
        log.info("Creando archivo nuevo en Drive...")
        metadata = {
            "name":    NOMBRE_EN_DRIVE,
            "parents": [DRIVE_FOLDER_ID]
        }
        file = service.files().create(
            body=metadata,
            media_body=media,
            fields="id"
        ).execute()
        archivo_id = file.get("id")
        log.info(f"✅ Archivo creado en Drive. ID: {archivo_id}")
 
    log.info(f"URL: https://drive.google.com/file/d/{archivo_id}/view")
    return archivo_id
 
 
def main():
    log.info("=" * 55)
    log.info("  PASO 2 — Subir Excel a Google Drive")
    log.info("=" * 55)
 
    excel_txt = Path("ultimo_excel.txt")
    if not excel_txt.exists():
        raise FileNotFoundError(
            "No se encontró 'ultimo_excel.txt'. "
            "Ejecuta primero 01_restaurar_y_extraer.py"
        )
 
    ruta_excel = Path(excel_txt.read_text().strip())
    if not ruta_excel.exists():
        raise FileNotFoundError(f"El archivo Excel no existe: {ruta_excel}")
 
    log.info(f"Subiendo: {ruta_excel.name} ({ruta_excel.stat().st_size/1e6:.1f} MB)")
    subir_excel(ruta_excel)
 
 
if __name__ == "__main__":
    main()