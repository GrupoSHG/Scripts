"""
01_restaurar_y_extraer.py
=========================
1. Restaura el .bak más reciente en SQL Server (Windows Auth)
2. Ejecuta el query de Ventas Full para el año actual
3. Exporta el resultado a Excel formateado

Requiere: pip install pyodbc pandas openpyxl
"""

import os
import shutil
import time
import logging
from datetime import datetime
from pathlib import Path

import pyodbc
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
SQL_SERVER     = r"localhost\SQLEXPRESS"
NOMBRE_BD      = "T779354202A"
CARPETA_BAK    = r"C:\Backups\Manager"
CARPETA_SALIDA = r"C:\Reportes\VentasFull"
DATA_DIR       = r"C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA"
AÑO_ACTUAL     = datetime.now().year
# ─────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler("pipeline_ventas.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

QUERY_VENTAS = f"""
SELECT
    CASE
        WHEN TIPODOC=1  THEN 'FAV'
        WHEN TIPODOC=3  THEN 'BOV'
        WHEN TIPODOC=79 THEN 'NDV'
        WHEN TIPODOC=4  THEN 'NCV'
        ELSE ' '
    END AS DOCTO,
    NUMFACT AS NUM_DOCTO,
    SUBSTRING(CHOI_DB.DESCRIP,1,25) AS TIPO_VTA,
    docu_db.FECHA AS FECHA_EMISION,
    VENCIMIE AS FECHA_VENCIMIE,
    perso_db.codigo AS COD_VDDOR,
    perso_db.nombre AS NOM_VDDOR,
    perso_db.apellido AS APELL_VDDOR,
    DATENAME(M, docu_db.FECHA) AS MES,
    rut,
    SUBSTRING(razsoc2,1,40) AS CLIENTE,
    clien_db.clase1 AS TIPO_CLIENTE,
    art_db.codigo AS COD_ARTICULO,
    SUBSTRING(docde_db.descrip,1,45) AS PRODUCTO,
    (SELECT codigo FROM CHOI_DB WHERE art_db.CLASE1=CHOI_DB.DESCRIP AND tipo=6) AS CodClase1,
    art_db.CLASE1,
    (SELECT codigo FROM CHOI_DB WHERE art_db.CLASE2=CHOI_DB.DESCRIP AND tipo=7) AS CodClase2,
    art_db.CLASE2,
    CASE WHEN TIPODOC=4 THEN docde_db.cantidad*-1 ELSE docde_db.CANTIDAD END AS CANTIDAD,
    unidmed,
    monevta,
    DOCDE_DB.precunit AS PRECIO_VTA_BASE,
    TASACBIO AS TCAMBIO,
    DOCDE_DB.DESCTO AS PCT_DESCTO_LINEA,
    DOCDE_DB.PRECUNIT*TASACBIO - DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100) AS DESCTO_LINEA_PESOS,
    DOCDE_DB.PRECUNIT*TASACBIO - DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCU_DB.DCTOPJE/100) AS DESCTO_PORTADA_PESOS,
    ((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100)) AS PRECIO_VTA_UNIT,
    VALPROM AS CTO_PROM_UNIT,
    COSTOREP AS CTO_REPOS_UNIT,
    PULTCOM AS CTO_ULT_COMPRA_UNIT,
    DOCDE_DB.cantidad*((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100)) AS TOTAL_NETO,
    CANTIDAD*VALPROM AS CTO_PROMEDIO_TOTAL,
    CANTIDAD*COSTOREP AS CTO_REPOS_TOTAL,
    CANTIDAD*PULTCOM AS CTO_ULT_COMPRA_TOTAL,
    CASE WHEN TIPODOC=4 THEN
        DOCDE_DB.CANTIDAD*-1*(((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100))-VALPROM)
    ELSE
        DOCDE_DB.CANTIDAD*(((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100))-VALPROM)
    END AS RESULTADO_CTO_PROM,
    CASE WHEN TIPODOC=4 THEN
        DOCDE_DB.CANTIDAD*-1*(((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100))-COSTOREP)
    ELSE
        DOCDE_DB.CANTIDAD*(((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100))-COSTOREP)
    END AS RESULTADO_CTO_REPOS,
    CASE WHEN TIPODOC=4 THEN
        DOCDE_DB.CANTIDAD*-1*(((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100))-PULTCOM)
    ELSE
        DOCDE_DB.CANTIDAD*(((DOCDE_DB.PRECUNIT*TASACBIO-((DOCDE_DB.PRECUNIT*TASACBIO-DOCDE_DB.PRECUNIT*TASACBIO*(1-DOCDE_DB.DESCTO/100))))*(1-DOCU_DB.DCTOPJE/100))-PULTCOM)
    END AS RESULTADO_CTO_ULT_COMPRA

FROM art_db, PLAN_DB,
    docde_db LEFT OUTER JOIN cent_db ON docde_db.cencosto = cent_db.nreguist,
    DOCU_DB LEFT OUTER JOIN CHOI_DB ON DOCU_DB.TIPOVTA = CHOI_DB.NUMREG
            LEFT OUTER JOIN PERSO_DB ON perso_db.numreg = docu_db.codvend
            LEFT OUTER JOIN CLIEN_DB ON docu_db.nrutclie = clien_db.nreguist

WHERE (tipodoc IN (1, 3, 4, 79, 146))
  AND docu_db.numreg = docde_db.numrecor
  AND docde_db.ncodart = art_db.nreguist
  AND DOCDE_DB.CTACTBLE = PLAN_DB.NREGUIST
  AND ART_DB.CODIGO <> '-'
  AND fecha >= CONVERT(datetime, '01/01/{AÑO_ACTUAL}', 103)
  AND fecha <= CONVERT(datetime, '31/12/{AÑO_ACTUAL}', 103)
ORDER BY NUMFACT
"""


def conectar_master() -> pyodbc.Connection:
    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={SQL_SERVER};"
        f"DATABASE=master;"
        f"Trusted_Connection=yes;"
    )
    return pyodbc.connect(conn_str, autocommit=True)


def obtener_bak_reciente() -> Path:
    # Primero intenta leer la ruta guardada por el script de descarga
    ultimo_txt = Path("ultimo_bak.txt")
    if ultimo_txt.exists():
        ruta = Path(ultimo_txt.read_text().strip())
        if ruta.exists():
            log.info(f"Usando .bak de ultimo_bak.txt: {ruta.name}")
            return ruta

    # Si no, busca el más reciente en la carpeta
    archivos = list(Path(CARPETA_BAK).glob("*.bak"))
    if not archivos:
        raise FileNotFoundError(f"No se encontraron archivos .bak en {CARPETA_BAK}")
    return max(archivos, key=lambda f: f.stat().st_mtime)


def detectar_data_dir() -> str:
    if Path(DATA_DIR).exists():
        return DATA_DIR
    bases = [
        r"C:\Program Files\Microsoft SQL Server",
        r"C:\Program Files (x86)\Microsoft SQL Server",
    ]
    for base in bases:
        base_path = Path(base)
        if not base_path.exists():
            continue
        for carpeta in sorted(base_path.iterdir(), reverse=True):
            data = carpeta / "MSSQL" / "DATA"
            if data.exists():
                log.info(f"Carpeta DATA detectada: {data}")
                return str(data)
    raise FileNotFoundError("No se encontró la carpeta DATA de SQL Server.")


def restaurar_bd(bak_path: Path):
    log.info(f"Restaurando {bak_path.name} como '{NOMBRE_BD}'...")

    # Copia el .bak a la carpeta DATA donde SQL Server tiene permisos
    data_dir    = detectar_data_dir()
    bak_en_data = Path(data_dir) / bak_path.name
    if not bak_en_data.exists():
        log.info(f"Copiando .bak a {bak_en_data}...")
        shutil.copy2(str(bak_path), str(bak_en_data))
    bak_path = bak_en_data

    conn   = conectar_master()
    cursor = conn.cursor()

    # Cierra conexiones activas
    cursor.execute(f"""
        IF EXISTS (SELECT name FROM sys.databases WHERE name = N'{NOMBRE_BD}')
            ALTER DATABASE [{NOMBRE_BD}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
    """)

    # Obtiene nombres lógicos del .bak
    cursor.execute(f"RESTORE FILELISTONLY FROM DISK = N'{bak_path}'")
    files        = cursor.fetchall()
    logical_data = next((r[0] for r in files if r[2].upper() == 'D'), None)
    logical_log  = next((r[0] for r in files if r[2].upper() == 'L'), None)

    if not logical_data or not logical_log:
        raise Exception("No se pudieron identificar los archivos lógicos del .bak")

    log.info(f"Archivos lógicos → Data: {logical_data}, Log: {logical_log}")

    data_file = os.path.join(data_dir, f"{NOMBRE_BD}.mdf")
    log_file  = os.path.join(data_dir, f"{NOMBRE_BD}_log.ldf")

    log.info("Ejecutando RESTORE DATABASE...")
    cursor.execute(f"""
        RESTORE DATABASE [{NOMBRE_BD}]
        FROM DISK = N'{bak_path}'
        WITH
            MOVE N'{logical_data}' TO N'{data_file}',
            MOVE N'{logical_log}'  TO N'{log_file}',
            REPLACE,
            RECOVERY,
            STATS = 10
    """)

    # Espera a que la BD quede ONLINE antes de continuar
    log.info("Esperando que la BD quede en línea...")
    for intento in range(30):
        time.sleep(3)
        try:
            check  = conectar_master()
            c      = check.cursor()
            c.execute(f"SELECT state_desc FROM sys.databases WHERE name = N'{NOMBRE_BD}'")
            row = c.fetchone()
            check.close()
            if row and row[0] == 'ONLINE':
                log.info(f"✅ BD en línea tras {intento+1} intentos.")
                break
            log.info(f"  Estado actual: {row[0] if row else 'desconocido'}")
        except Exception as e:
            log.warning(f"  Intento {intento+1}: {e}")

   # Vuelve a multiusuario con reintentos
    log.info("Configurando MULTI_USER...")
    for intento in range(10):
        try:
            time.sleep(3)
            conn2 = conectar_master()
            conn2.cursor().execute(f"ALTER DATABASE [{NOMBRE_BD}] SET MULTI_USER")
            conn2.close()
            log.info("✅ BD configurada como MULTI_USER.")
            break
        except Exception as e:
            log.warning(f"  Intento {intento+1}/10: {e}")
    
    conn.close()

    # Elimina la copia temporal
    bak_en_data.unlink(missing_ok=True)
    log.info(f"✅ BD '{NOMBRE_BD}' restaurada correctamente.")


def extraer_ventas() -> pd.DataFrame:
    log.info(f"Conectando a '{NOMBRE_BD}' para extraer ventas {AÑO_ACTUAL}...")
    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={SQL_SERVER};"
        f"DATABASE={NOMBRE_BD};"
        f"Trusted_Connection=yes;"
    )
    conn = pyodbc.connect(conn_str)
    df   = pd.read_sql(QUERY_VENTAS, conn)
    conn.close()
    log.info(f"Registros extraídos: {len(df):,}")
    return df


def exportar_excel(df: pd.DataFrame) -> Path:
    Path(CARPETA_SALIDA).mkdir(parents=True, exist_ok=True)
    fecha_hoy      = datetime.now().strftime("%Y-%m-%d")
    nombre_archivo = f"VentasFull_{fecha_hoy}.xlsx"
    ruta_excel     = Path(CARPETA_SALIDA) / nombre_archivo

    log.info(f"Exportando a Excel: {ruta_excel}")

    cols_pesos = [
        "DESCTO_LINEA_PESOS", "DESCTO_PORTADA_PESOS", "PRECIO_VTA_UNIT",
        "CTO_PROM_UNIT", "CTO_REPOS_UNIT", "CTO_ULT_COMPRA_UNIT",
        "TOTAL_NETO", "CTO_PROMEDIO_TOTAL", "CTO_REPOS_TOTAL",
        "CTO_ULT_COMPRA_TOTAL", "RESULTADO_CTO_PROM",
        "RESULTADO_CTO_REPOS", "RESULTADO_CTO_ULT_COMPRA", "PRECIO_VTA_BASE"
    ]

    with pd.ExcelWriter(ruta_excel, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Ventas", index=False)
        ws = writer.sheets["Ventas"]

        header_fill = PatternFill("solid", start_color="2F5496")
        header_font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
        thin        = Side(style="thin", color="CCCCCC")
        border      = Border(left=thin, right=thin, bottom=thin)

        for col_idx in range(1, len(df.columns) + 1):
            cell           = ws.cell(row=1, column=col_idx)
            cell.fill      = header_fill
            cell.font      = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        ws.row_dimensions[1].height = 30

        col_indices_pesos = {
            df.columns.get_loc(c) + 1
            for c in cols_pesos if c in df.columns
        }

        for row in ws.iter_rows(min_row=2, max_row=ws.max_row, max_col=ws.max_column):
            for cell in row:
                cell.font   = Font(name="Arial", size=9)
                cell.border = border
                if cell.column in col_indices_pesos:
                    cell.number_format = '#,##0'
                elif "CANTIDAD" in df.columns and cell.column == df.columns.get_loc("CANTIDAD") + 1:
                    cell.number_format = '#,##0.00'
                elif "PCT_DESCTO_LINEA" in df.columns and cell.column == df.columns.get_loc("PCT_DESCTO_LINEA") + 1:
                    cell.number_format = '0.00%'

        for col_idx, col_name in enumerate(df.columns, 1):
            max_len = max(
                len(str(col_name)),
                df[col_name].astype(str).str.len().max() if len(df) > 0 else 0
            )
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 2, 40)

        ws.freeze_panes    = "A2"
        ws.auto_filter.ref = ws.dimensions

    log.info(f"✅ Excel generado: {ruta_excel} ({ruta_excel.stat().st_size/1e6:.1f} MB)")
    return ruta_excel


def main():
    log.info("=" * 55)
    log.info("  PASO 1 — Restaurar BD y extraer Ventas Full")
    log.info("=" * 55)

    bak = obtener_bak_reciente()
    log.info(f"Usando backup: {bak.name}")

    restaurar_bd(bak)
    df         = extraer_ventas()
    ruta_excel = exportar_excel(df)

    with open("ultimo_excel.txt", "w") as f:
        f.write(str(ruta_excel))

    log.info(f"✅ Listo → {ruta_excel}")
    return ruta_excel


if __name__ == "__main__":
    main()
